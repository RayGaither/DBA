SELECT *
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255; 
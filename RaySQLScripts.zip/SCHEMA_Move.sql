ALTER SCHEMA TestSchema
TRANSFER dbo.<TableName>;



ALTER SCHEMA TestSchema
TRANSFER [dbo].[OLE DB Destination]

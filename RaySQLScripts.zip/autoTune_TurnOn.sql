alter database current
set automatic_tuning(
		force_last_good_plan = ON
		);
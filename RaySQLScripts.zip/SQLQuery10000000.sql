select *
from [JBLPRODSQL03\COMMERCIAL].[KVPROD].[dbo].[DBA_tswitch_matrix]

SELECT CURRENT_USER;  

	
SELECT HOST_NAME() AS HostName, SUSER_NAME() LoggedInUser

/***************************************************************************

   FILE NAME:  <tablename>Tbl.sql
   
 DESCRIPTION:  
					
      AUTHOR:  Ray Gaither
     CREATED:  <date>

MODIFICATION HISTORY:
WHEN     		WHO		  		WHAT
-------------  --------------- -------------------------------------------------------
16 Apr 2021 	David C. Rudd	Created.  

***************************************************************************/
create table dbo.<tablename. --directly BULK loaded without a View.
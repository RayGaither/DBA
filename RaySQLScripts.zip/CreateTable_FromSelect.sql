
--select *
--into [Ray].[JournalLinesRaasImportTest] 
--from [dbo].[JournalLinesRaasImport]



USE [ankura_dw]
GO

/****** Object:  Table [dbo].[CurrencyConversionRatesImport]    Script Date: 8/3/2021 9:21:49 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CurrencyConversionRatesImport](
	[DataSourceCode] [varchar](100) NULL,
	[Currency_Conversion_Rate_Reference_ID] [varchar](100) NULL,
	[Effective_Timestamp] [datetime] NULL,
	[From_Currency_Reference_ID] [varchar](100) NULL,
	[From_Currency_ID] [varchar](100) NULL,
	[From_Currency_Numeric_Code] [varchar](100) NULL,
	[Target_Currency_Reference_ID] [varchar](100) NULL,
	[Target_Currency_ID] [varchar](100) NULL,
	[Target_Currency_Numeric_Code] [varchar](100) NULL,
	[Currency_Rate_Type_Reference_ID] [varchar](100) NULL,
	[Currency_Rate_Type_ID] [varchar](100) NULL,
	[Currency_Rate_String] [varchar](100) NULL,
	[Effective_Timestamp_String] [varchar](100) NULL,
	[Currency_Rate] [decimal](16, 6) NULL,
	[batchId] [int] NULL,
	[batchPage] [int] NULL
) ON [PRIMARY]
GO



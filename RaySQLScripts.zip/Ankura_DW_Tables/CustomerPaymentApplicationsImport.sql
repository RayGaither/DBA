USE [ankura_dw]
GO

/****** Object:  Table [dbo].[CustomerPaymentApplicationsImport]    Script Date: 8/3/2021 11:56:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--DROP TABLE [dbo].[CustomerPaymentApplicationsImport]
--go



CREATE TABLE [dbo].[CustomerPaymentApplicationsImport](
	[PaymentApplicationWID] [varchar](50) NULL,
	[PaymentWID] [varchar](50) NULL,
	[PaymentApplicationInvoice] [varchar](100) NULL,
	[PaymentApplicationAmountInUSD] [varchar](50) NULL,
	[PaymentApplicationAmount] [varchar](50) NULL,
	[PaymentDateString] [varchar](50) NULL,
	[PaymentDate] [datetime] NULL,
	[batchId] [bigint] NULL,
	[CustomerInvoiceID] [varchar](50) NULL
) ON [PRIMARY]
GO



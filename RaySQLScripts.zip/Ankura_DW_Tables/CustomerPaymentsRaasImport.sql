USE [ankura_dw]
GO

/****** Object:  Table [dbo].[CustomerPaymentsRaasImport]    Script Date: 8/3/2021 9:34:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerPaymentsRaasImport](
	[PaymentAmountInUSD] [varchar](100) NULL,
	[Status] [varchar](100) NULL,
	[ApplicationStatus] [varchar](100) NULL,
	[Company] [varchar](100) NULL,
	[Customer] [varchar](100) NULL,
	[LastUpdated] [varchar](50) NULL,
	[LastUpdatedString] [varchar](50) NULL,
	[Invoices] [varchar](500) NULL,
	[OnAccountAmount] [varchar](100) NULL,
	[PaymentType] [varchar](100) NULL,
	[TransactionNumber] [varchar](100) NULL,
	[PaymentInDeposit] [char](1) NULL,
	[PaymentInDepositYN] [char](1) NULL,
	[OverpaymentAmountInUSD] [varchar](100) NULL,
	[PaymentDate] [varchar](100) NULL,
	[PaymentDateString] [varchar](50) NULL,
	[WID] [varchar](100) NULL,
	[PaymentAmount] [varchar](100) NULL,
	[OverpaymentAmount] [varchar](100) NULL,
	[CustomerPayment] [varchar](250) NULL,
	[CustomerID] [varchar](100) NULL,
	[Currency] [varchar](100) NULL,
	[batchId] [bigint] NULL
) ON [PRIMARY]
GO



SELECT *
FROM SYSOBJECTS
WHERE xtype = 'U'
order by 1

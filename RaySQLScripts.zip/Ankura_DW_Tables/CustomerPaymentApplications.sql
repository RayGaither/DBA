USE [ankura_dw]
GO

/****** Object:  Table [dbo].[CustomerPaymentApplications]    Script Date: 8/3/2021 11:55:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/****** Object:  Table [dbo].[CustomerPaymentApplications]    Script Date: 8/3/2021 12:26:26 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomerPaymentApplications]') AND type in (N'U'))
--DROP TABLE [dbo].[CustomerPaymentApplications]
--GO


CREATE TABLE [dbo].[CustomerPaymentApplications](
	[PaymentWID] [varchar](50) NULL,
	[PaymentApplicationWID] [varchar](50) NULL,
	[PaymentApplicationInvoice] [varchar](100) NULL,
	[PaymentApplicationAmountInUSD] [numeric](19, 4) NULL,
	[PaymentApplicationAmount] [numeric](19, 4) NULL,
	[batchId] [bigint] NULL,
	[LoadedDate] [datetime] NULL,
	[PaymentDate] [datetime] NULL,
	[CustomerInvoiceID] [varchar](50) NULL
) ON [PRIMARY]
GO



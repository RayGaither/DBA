sp_who2

dba_maint.dbo.sp_whoisactive

[dbo].[sp_AllNightLog]

[dbo].[sp_BlitzAnalysis] @OutputDatabaseName = N'DBA_Maint'

[dbo].[sp_BlitzFirst]

[dbo].[sp_Blitz] --Somebody has been messing with your trace files. Check the files are present at C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Log\log.trc




[dbo].[sp_BlitzCache] @databasename = 'ankura_dw'

